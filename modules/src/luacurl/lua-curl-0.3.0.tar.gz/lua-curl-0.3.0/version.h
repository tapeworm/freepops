#define LUACURL_VERSION "0.3.0"
#define LUACURL_AUTHOR "Enrico Tassi <gareuselesinge@users.sourceforge.net>"
#define LUACURL_LICENSE "Dual: GPL and MIT/X"
