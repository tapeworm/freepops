print(curl.version())
table.foreach(package.loaded,print)
