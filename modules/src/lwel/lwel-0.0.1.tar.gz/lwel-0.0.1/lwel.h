/******************************************************************************
 * $Id: head.h.txt,v 1.3 2007/01/13 22:36:23 gareuselesinge Exp $
 * This file is part of FreePOPs (http://www.freepops.org)                    *
 * This file is distributed under the terms of GNU GPL license.               *
 ******************************************************************************/


/******************************************************************************/
 /*!
  * \file   lwel.h
  * \brief  Windows Event Logging for Lua
  * eventual Emit windows event from lua
  * \author Enrico Tassi <gareuselesinge@users.sourceforge.net>
  */
/******************************************************************************/

#ifndef LWEL_H
#define LWEL_H

int luaopen_wel_core(lua_State*);

#endif
