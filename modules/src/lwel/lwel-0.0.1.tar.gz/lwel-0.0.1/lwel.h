#ifndef LWEL_H
#define LWEL_H

int luaopen_wel(lua_State*);

#endif
