#!%%INTERPRETER%%

function mangle(l,m)
	if l == "" then return "" end

	local beg,len = string.find(l,"#define",1,true)
	if beg == 1 and len == 7 then
		return mangle_define(l)
	else
		return mangle_function(l,m)
	end
end	

function mangle_function(l,m)
	--print(l)
	l = " "..l
	l = string.gsub(l,",",", ")
	l = string.gsub(l,"%(","( ")
	l = string.gsub(l,"*"," ")
	l = string.gsub(l," void ","")
	l = string.gsub(l," char ","")
	l = string.gsub(l," int ","")
	l = string.gsub(l," double ","")
	l = string.gsub(l," long ","")
	l = string.gsub(l," short ","")
	l = string.gsub(l," const ","")
	l = string.gsub(l,";"," return nil end")

	l = string.gsub(l,"([A-Za-z0-9%_]+)%s*@%s*([A-Za-z0-9%_]+)%s*(","%2")
	
	l = string.gsub(l,"  "," ")
	l = string.gsub(l,"%( ","(")
	l = string.gsub(l,", ",",")
	
	while (string.find(l," ",1,true)) == 1 do
		l = string.sub(l,2)
	end
	--print(l)
	if m then
		return "function "..m.."."..l
	else
		return "function "..l
	end
end

function mangle_define(l)
	return string.gsub(l,"#define%s+([A-Za-z0-9%_]+)%s+([A-Za-z0-9%_]+)","%1 = %2")
end

function parse_file(_,f)
	print("Examining "..f.."\n")
	local status = nil
	local modulename = nil
	local out,err = io.open(f..".lua","w")
	if not out then
		print(err)
		os.exit(1)
	end
	for l in io.lines(f) do
		if not status then
			local rc,len = string.find(l,"//---",1,true)
			if rc == 1 and len == 5 then
				status = "in"
				out:write(string.sub(l,3).."\n")
			end
			local rc,len = string.find(l,"$[",1,true)
			if rc == 1 and len == 2 then
				status = "out"
			end
			local rc,len = string.find(l,"module%s+[%w_]+",1)
			if rc == 1 then
				modulename = string.gsub(l,"module%s+([%w_]+).*","%1")
			end

		elseif status == "in" then
			local rc,len = string.find(l,"//--",1,true)
			if rc == 1 and len == 4 then
				out:write(string.sub(l,3).."\n")
			else
				out:write(mangle(l,modulename).."\n\n")
				status = nil
			end
		elseif status == "out" then
			local rc,len = string.find(l,"$]",1,true)
			if rc == 1 and len == 2 then
				status = nil
			else
				out:write(l.."\n")
			end
		end
	end
	out:close()
end






--<==========================================================================>--
-- main

files = {}

table.foreachi(arg,function(i,f) if i > 0 then files[i] = f end end)

table.foreach(files,parse_file)
