#############
## This is the custom file to override the options on the config_* files.
# Example:
#
# CCFLAGS = ['-g', '-Wall']
