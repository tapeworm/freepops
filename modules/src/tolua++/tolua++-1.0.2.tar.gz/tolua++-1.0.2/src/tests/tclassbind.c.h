/*
** Lua binding: tclass
** Generated automatically by tolua 5.0a-CDLVS6 on 10/20/03 18:27:06.
*/

/* Exported function */
TOLUA_API int tolua_tclass_open (lua_State* tolua_S);

